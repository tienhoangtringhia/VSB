#ifndef AIC_VSB_H_
#define AIC_VSB_H_

void AIC_init(void);
void AIC_off(void);
void AIC_read2(Int16*, Int16*);
void AIC_write2(Int16, Int16);
void AIC_vsb(void);

#endif /*AIC_VSB_H_*/