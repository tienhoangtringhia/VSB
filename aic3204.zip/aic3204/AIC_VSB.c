#include <usbstk5515.h>
#include <usbstk5515_gpio.h>
#include <usbstk5515_i2c.h>
#include "stdio.h"
#include "sinewaves.h"
#include "AIC_VSB.h"

#define AIC3204_I2C_ADDR 0x18
#define Rcv 0x08
#define Xmit 0x20
#define XmitL 0x10
#define XmitR 0x20
#define Fc 5000			// The carrier frequency
#define PI 3.141592654
#define Amp 3				// The amplitude of carrier wave
#define N 1000				// The number of samples

extern Int16 AIC3204_rset( Uint16 regnum, Uint16 regval);

Int16 left_input;
Int16 right_input;
Int16 left_output;
Int16 right_output;

Int16 BP[256] = {
     -114,    -61,     17,     86,    114,     90,     27,    -46,    -95,
     -100,    -59,      5,     63,     89,     74,     28,    -27,    -65,
      -70,    -45,     -3,     34,     51,     44,     18,     -9,    -26,
      -27,    -16,     -2,      5,      3,     -3,     -5,      2,     17,
       30,     29,     11,    -22,    -53,    -64,    -44,      4,     59,
       95,     90,     38,    -41,   -110,   -136,    -98,     -8,     97,
      166,    162,     80,    -48,   -165,   -214,   -165,    -34,    124,
      235,    244,    138,    -41,   -212,   -294,   -244,    -76,    137,
      298,    328,    207,    -17,   -245,   -369,   -327,   -131,    134,
      349,    410,    284,     21,   -262,   -433,   -411,   -198,    114,
      383,    483,    364,     73,   -260,   -482,   -488,   -270,     78,
      397,    542,    440,    134,   -239,   -510,   -552,   -342,     28,
      391,    580,    506,    200,   -201,   -516,   -598,   -408,    -30,
      365,    596,    557,    264,   -151,   -499,   -622,   -462,    -92,
      321,    588,    588,    321,    -92,   -462,   -622,   -499,   -151,
      264,    557,    596,    365,    -30,   -408,   -598,   -516,   -201,
      200,    506,    580,    391,     28,   -342,   -552,   -510,   -239,
      134,    440,    542,    397,     78,   -270,   -488,   -482,   -260,
       73,    364,    483,    383,    114,   -198,   -411,   -433,   -262,
       21,    284,    410,    349,    134,   -131,   -327,   -369,   -245,
      -17,    207,    328,    298,    137,    -76,   -244,   -294,   -212,
      -41,    138,    244,    235,    124,    -34,   -165,   -214,   -165,
      -48,     80,    162,    166,     97,     -8,    -98,   -136,   -110,
      -41,     38,     90,     95,     59,      4,    -44,    -64,    -53,
      -22,     11,     29,     30,     17,      2,     -5,     -3,      3,
        5,     -2,    -16,    -27,    -26,     -9,     18,     44,     51,
       34,     -3,    -45,    -70,    -65,    -27,     28,     74,     89,
       63,      5,    -59,   -100,    -95,    -46,     27,     90,    114,
       86,     17,    -61,   -114
};
     
 Int16 Temp[256] = {
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0
};

/*****************************************************************************/
/* DSB()                                                                     */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* Perform DSB modulation by multiplying input by sinewave.                  */
/*                                                                           */
/*                                                                           */
/* PARAMETER 1: Audio input.                                                 */ 
/* PARAMETER 2: Carrier signal. Frequency fc                                 */
/*                                                                           */
/*****************************************************************************/

static int DSB( int input, int fc)
{ 
  signed long result;
  Int16 carrierwave;
  /* For TMS320C5505 it is necessary to first cast one int to long before */
  /* carrying out the multiplication                                      */
  carrierwave = generate_sinewave_1 (fc, 32767); 			// The amplitude of fc sine wave 1.000 = 32767
  result = Amp * ( ( (long) input * carrierwave) >> 15);    // 
  return ( (int) result);
}

/*****************************************************************************/
/* Filter()                                                                  */
/*---------------------------------------------------------------------------*/
/* Apply VSB Filter on DSB signal to obtain VSB modulation.                  */
/* PARAMETER 1: DSB Signal.                                                  */ 
/*****************************************************************************/

static Int16 Filter(int input)
{	signed long result = 0;
	int i;
	//Dich cac gia tri cu di 1 don vi
	for (i = 254; i >= 0 ; i--)
	{
		result = result + (long)BP[i+1] * (long)Temp[i];
		Temp[i+1] = Temp[i];
	}
	result = result + (long)input * (long)BP[0];
	result = result >> 15;
	Temp[0] = input;
    return ( (Int16) result);
}

void AIC_init(void)
{
/* Configure AIC3204 */
    AIC3204_rset( 0, 0 );      // Select page 0
    AIC3204_rset( 1, 1 );      // Reset codec
    AIC3204_rset( 0, 1 );      // Select page 1
    AIC3204_rset( 1, 8 );      // Disable crude AVDD generation from DVDD
    AIC3204_rset( 2, 1 );      // Enable Analog Blocks, use LDO power
    AIC3204_rset( 0, 0 );
    /* PLL and Clocks config and Power Up  */
    AIC3204_rset( 27, 0x0d );  // BCLK and WCLK are set as o/p; AIC3204(Master)
    AIC3204_rset( 28, 0x00 );  // Data ofset = 0
    AIC3204_rset( 4, 3 );      // PLL setting: PLLCLK <- MCLK, CODEC_CLKIN <-PLL CLK
    AIC3204_rset( 6, 7 );      // PLL setting: J=7
    AIC3204_rset( 7, 0x06 );   // PLL setting: HI_BYTE(D=1680)
    AIC3204_rset( 8, 0x90 );   // PLL setting: LO_BYTE(D=1680)
    AIC3204_rset( 30, 0x88 );  // For 32 bit clocks per frame in Master mode ONLY
                               // BCLK=DAC_CLK/N =(12288000/8) = 1.536MHz = 32*fs
    AIC3204_rset( 5, 0x91 );   // PLL setting: Power up PLL, P=1 and R=1
    AIC3204_rset( 13, 0 );     // Hi_Byte(DOSR) for DOSR = 128 decimal or 0x0080 DAC oversamppling
    AIC3204_rset( 14, 0x80 );  // Lo_Byte(DOSR) for DOSR = 128 decimal or 0x0080
    AIC3204_rset( 20, 0x80 );  // AOSR for AOSR = 128 decimal or 0x0080 for decimation filters 1 to 6
    AIC3204_rset( 11, 0x82 );  // Power up NDAC and set NDAC value to 2
    AIC3204_rset( 12, 0x87 );  // Power up MDAC and set MDAC value to 7
    AIC3204_rset( 18, 0x87 );  // Power up NADC and set NADC value to 7
    AIC3204_rset( 19, 0x82 );  // Power up MADC and set MADC value to 2
    /* DAC ROUTING and Power Up */
    AIC3204_rset( 0, 1 );      // Select page 1
    AIC3204_rset( 12, 0x08 );   // LDAC AFIR routed to HPL
    AIC3204_rset( 13, 0x08 );   // RDAC AFIR routed to HPR
    AIC3204_rset( 0,  0x00 );      // Select page 0
    AIC3204_rset( 64, 0x02 );     // Left vol=right vol
    AIC3204_rset( 65, 0x00);      // Left DAC gain to 0dB VOL; Right tracks Left
    AIC3204_rset( 63, 0xd4 );  // Power up left,right data paths and set channel
    AIC3204_rset( 0, 1 );      // Select page 1
    AIC3204_rset( 0x10, 0x00 );// Unmute HPL , 0dB gain
    AIC3204_rset( 0x11, 0x00 );// Unmute HPR , 0dB gain
    AIC3204_rset( 9, 0x30 );   // Power up HPL,HPR
    AIC3204_rset( 0, 0 );      // Select page 0
    USBSTK5515_wait( 100 );    // wait
    /* ADC ROUTING and Power Up */
    AIC3204_rset( 0, 1 );      // Select page 1
    AIC3204_rset( 0x34, 0x30 );// STEREO 1 Jack
		                       // IN2_L to LADC_P through 40 kohm
    AIC3204_rset( 0x37, 0x30 );// IN2_R to RADC_P through 40 kohmm
    AIC3204_rset( 0x36, 3 );   // CM_1 (common mode) to LADC_M through 40 kohm
    AIC3204_rset( 0x39, 0xc0 );// CM_1 (common mode) to RADC_M through 40 kohm
    AIC3204_rset( 0x3b, 0 );   // MIC_PGA_L unmute
    AIC3204_rset( 0x3c, 0 );   // MIC_PGA_R unmute
    AIC3204_rset( 0, 0 );      // Select page 0
    AIC3204_rset( 0x51, 0xc0 );// Powerup Left and Right ADC
    AIC3204_rset( 0x52, 0 );   // Unmute Left and Right ADC
    
    AIC3204_rset( 0, 0 );    // Select page 0
    USBSTK5515_wait( 200 );    // Wait
    
    /* I2S settings */
    I2S0_SRGR = 0x0;
    I2S0_CR = 0x8010;    // 16-bit word, slave, enable I2C
    I2S0_ICMR = 0x3f;    // Enable interrupts
}

void AIC_read2(Int16 * right1, Int16 * left1)
{
	Int16 data1, data2, data3, data4;
	data3 = I2S0_W0_MSW_R;  // 16 bit left channel received audio data
    data1 = I2S0_W0_LSW_R;	// Least Significant word
    data4 = I2S0_W1_MSW_R;  // 16 bit right channel received audio data
    data2 = I2S0_W1_LSW_R;  // Least significant word
    while((Rcv & I2S0_IR) == 0); // Wait for the Interrupt to move forward, for timing
    *right1 = data4;
    *left1 = data3;
}

void AIC_write2(Int16 data_right, Int16 data_left)
{
	I2S0_W0_MSW_W = data_left;  
	I2S0_W1_MSW_W = data_right; 
	while((Xmit & I2S0_IR) == 0); 
}

void AIC_off(void)
{
	I2S0_CR = 0x00;
}

void AIC_vsb(void)
{
	Int16 = 0;
	Int16 sample;
	
	AIC_init();
	
	printf("\nDieu che VSB Song mang 5 kHz");
	
	while(1)
	{
		for ( j = 0 ; j < 1000 ; j++ )
		{
            for ( sample = 0 ; sample < 48 ; sample++ )
            {
				AIC_read2(&left_input, &right_input);
				
				left_output = DSB(right_input, Fc);    // DSB modulating with carrier frequency 5 kHz
				left_output = Filter(left_output);     // Bandpass Filter -> VSB modulating 
				right_output = right_input;	           // Directly connect input to output
				
				AIC_write2(left_output, right_output);
			}
		}
		
	}
	
	AIC_off();
}